import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

def box(ax,x,y,w,h,t,fc,fs=9):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.02",fc=fc,ec="#444",lw=1))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs,family="serif")

# Fig 1: Scrum cycle
fig,ax=plt.subplots(figsize=(7.5,3.2)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,4)
items=[("Product\nBacklog","#fde9c9"),("Sprint\nPlanning","#fde9c9"),("Sprint Backlog\n(Task Board)","#f9d3d3"),
       ("Daily\nScrum","#d5ecd4"),("Sprint\nReview","#d3e2f5"),("Retro-\nspective","#d3e2f5")]
xs=[0.1,1.8,3.5,5.4,7.1,8.6]; ws=[1.4,1.4,1.7,1.4,1.4,1.3]
for (t,c),x,w in zip(items,xs,ws): box(ax,x,1.9,w,1.0,t,c)
for i in range(5):
    ax.add_patch(FancyArrowPatch((xs[i]+ws[i]+0.03,2.4),(xs[i+1]-0.03,2.4),arrowstyle="->",mutation_scale=12,color="#333"))
box(ax,3.5,0.5,3.3,0.8,"Potentially shippable Increment","#e8e1f3")
ax.add_patch(FancyArrowPatch((6.3,1.9),(5.4,1.32),arrowstyle="->",mutation_scale=12,color="#333"))
ax.text(5,3.5,"Sprint (1-2 weeks) - repeated until the product goal is met",ha="center",fontsize=9,style="italic",family="serif")
plt.savefig("fig_cycle.png",dpi=200,bbox_inches="tight"); plt.close()

# Fig 2: board snapshot day 5
fig,ax=plt.subplots(figsize=(7.5,3.6)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,5)
cols=[("Product\nBacklog",None,"#eeeeee"),("To Do",None,"#fde9c9"),("In Progress\n(WIP 3)",3,"#f9d3d3"),("Review\n(WIP 2)",2,"#d3e2f5"),("Done",None,"#d5ecd4")]
cards={0:["US4 Search (3)","US5 Export (2)","US6 Alerts (3)"],1:[],2:["US3 Admin\nreport (5)"],3:["US2 Submit\nfeedback (5)"],4:["US1 Login (3)"]}
w=1.9
for i,(n,l,c) in enumerate(cols):
    x=0.1+i*1.98
    ax.add_patch(FancyBboxPatch((x,0.1),w,4.1,boxstyle="round,pad=0.02",fc=c,ec="#555",lw=1,alpha=.55))
    ax.text(x+w/2,4.55,n,ha="center",va="center",fontsize=9,weight="bold",family="serif")
    for j,t in enumerate(cards[i]):
        ax.add_patch(FancyBboxPatch((x+0.12,3.2-j*1.05),w-0.24,0.8,boxstyle="round,pad=0.02",fc="#fffbe0",ec="#b59b00",lw=1))
        ax.text(x+w/2,3.6-j*1.05,t,ha="center",va="center",fontsize=8,family="serif")
plt.savefig("fig_board.png",dpi=200,bbox_inches="tight"); plt.close()

# Fig 3: burndown
act=[13,13,13,10,10,10,5,5,5,5,0]; ideal=[13-1.3*i for i in range(11)]
fig,ax=plt.subplots(figsize=(6.5,3.2))
ax.plot(range(11),ideal,"--",color="#888",label="Ideal"); ax.plot(range(11),act,"-o",color="#c0392b",label="Actual",ms=4)
ax.set_xlabel("Sprint day"); ax.set_ylabel("Story points remaining"); ax.set_xticks(range(11)); ax.grid(alpha=.3); ax.legend()
ax.set_title("Sprint 1 burndown chart",fontsize=10)
plt.savefig("fig_burndown.png",dpi=200,bbox_inches="tight"); plt.close()
