from scrumboard.board import *

b = Board(capacity=13)
for cid, t, p in [("US1", "Student login", 3), ("US2", "Submit feedback", 5),
                  ("US3", "Admin report view", 5), ("US4", "Search feedback", 3),
                  ("US5", "Export CSV", 2), ("US6", "Email alerts", 3)]:
    b.add(cid, t, p)
print("Product backlog:", sum(c.points for c in b.cards.values()), "points in 6 stories")
b.plan_sprint(["US1", "US2", "US3"])
print("Sprint 1 planned: 13 of 13 points\n")
b.end_day()
plan = {1: [("US1", DOING), ("US2", DOING)], 2: [("US1", REVIEW)], 3: [("US1", DONE)],
        4: [("US3", DOING)], 5: [("US2", REVIEW)], 6: [("US2", DONE)],
        7: [("US3", REVIEW)], 8: [("US3", DOING)], 9: [("US3", REVIEW)], 10: [("US3", DONE)]}
for day in range(1, SPRINT_DAYS + 1):
    for cid, st in plan[day]:
        b.move(cid, st)
    b.end_day()
    if day == 5:
        print("Board at end of day 5:"); print(b.render()); print()
try:
    b.move("US4", DOING)
except BoardError as e:
    print("Rule check ->", e)
print("Burndown (day0-10):", b.burndown)
print("Velocity:", b.velocity(), "points")
print("Final board:"); print(b.render())
