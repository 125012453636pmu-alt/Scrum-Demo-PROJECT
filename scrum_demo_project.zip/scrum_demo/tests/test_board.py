import pytest
from scrumboard.board import *


@pytest.fixture
def b():
    x = Board(capacity=13)
    for cid, pts in [("US1", 3), ("US2", 5), ("US3", 5), ("US4", 3), ("US5", 2), ("US6", 3)]:
        x.add(cid, "story " + cid, pts)
    return x


def test_new_card_starts_in_backlog(b):
    assert b.cards["US1"].state == BACKLOG

def test_duplicate_card_rejected(b):
    with pytest.raises(BoardError):
        b.add("US1", "again", 1)

def test_unknown_card_rejected(b):
    with pytest.raises(BoardError):
        b.move("US99", TODO)

def test_plan_sprint_moves_cards_to_todo(b):
    b.plan_sprint(["US1", "US2"])
    assert b.cards["US1"].state == TODO and b.cards["US4"].state == BACKLOG

def test_sprint_over_capacity_rejected(b):
    with pytest.raises(BoardError):
        b.plan_sprint(["US1", "US2", "US3", "US4"])

def test_backlog_card_cannot_be_pulled_directly(b):
    with pytest.raises(BoardError):
        b.move("US4", DOING)

def test_card_moves_one_column_forward(b):
    b.plan_sprint(["US1"]); b.move("US1", DOING)
    assert b.cards["US1"].state == DOING

def test_skipping_a_column_rejected(b):
    b.plan_sprint(["US1"])
    with pytest.raises(BoardError):
        b.move("US1", DONE)

def test_wip_limit_in_progress(b):
    b.plan_sprint(["US1", "US2", "US5", "US4"][:3] + [])
    b.add("X1", "extra", 0); b.plan_sprint(["X1"])
    for c in ["US1", "US2", "US5"]:
        b.move(c, DOING)
    with pytest.raises(BoardError):
        b.move("X1", DOING)

def test_wip_limit_review(b):
    b.add("A", "a", 0); b.add("B", "b", 0); b.add("C", "c", 0)
    b.plan_sprint(["A", "B", "C"])
    for c in "ABC":
        b.move(c, DOING)
    b.move("A", REVIEW); b.move("B", REVIEW)
    with pytest.raises(BoardError):
        b.move("C", REVIEW)

def test_review_can_send_card_back_for_rework(b):
    b.plan_sprint(["US1"]); b.move("US1", DOING); b.move("US1", REVIEW); b.move("US1", DOING)
    assert b.cards["US1"].state == DOING

def test_remaining_points_drop_only_when_done(b):
    b.plan_sprint(["US1", "US2"]); b.move("US1", DOING); b.move("US1", REVIEW)
    assert b.remaining() == 8
    b.move("US1", DONE)
    assert b.remaining() == 5

def test_velocity_counts_done_points(b):
    b.plan_sprint(["US1", "US2"])
    for s in (DOING, REVIEW, DONE):
        b.move("US1", s)
    assert b.velocity() == 3

def test_burndown_records_each_day(b):
    b.plan_sprint(["US1"]); b.end_day(); b.move("US1", DOING); b.end_day()
    assert b.burndown == [3, 3]
