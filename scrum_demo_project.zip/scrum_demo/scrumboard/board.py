"""Scrum task board with WIP limits, sprint capacity and burndown tracking."""
from dataclasses import dataclass

BACKLOG, TODO, DOING, REVIEW, DONE = "Product Backlog", "To Do", "In Progress", "Review", "Done"
FLOW = [BACKLOG, TODO, DOING, REVIEW, DONE]
WIP_LIMITS = {DOING: 3, REVIEW: 2}
SPRINT_DAYS = 10


@dataclass
class Card:
    cid: str
    title: str
    points: int
    state: str = BACKLOG
    owner: str = ""
    in_sprint: bool = False


class BoardError(Exception):
    pass


class Board:
    def __init__(self, capacity):
        self.capacity = capacity
        self.cards = {}
        self.burndown = []

    def add(self, cid, title, points, owner=""):
        if cid in self.cards:
            raise BoardError(f"duplicate card {cid}")
        self.cards[cid] = Card(cid, title, points, owner=owner)

    def _get(self, cid):
        if cid not in self.cards:
            raise BoardError(f"unknown card {cid}")
        return self.cards[cid]

    def plan_sprint(self, ids):
        total = sum(self._get(i).points for i in ids)
        if total > self.capacity:
            raise BoardError(f"{total} points exceed capacity {self.capacity}")
        for i in ids:
            card = self._get(i)
            card.in_sprint, card.state = True, TODO

    def _count(self, state):
        return sum(1 for c in self.cards.values() if c.state == state)

    def move(self, cid, new_state):
        card = self._get(cid)
        if not card.in_sprint:
            raise BoardError(f"{cid} is not in the sprint backlog")
        a, b = FLOW.index(card.state), FLOW.index(new_state)
        if not (b == a + 1 or (card.state == REVIEW and new_state == DOING)):
            raise BoardError(f"cannot move {card.state} -> {new_state}")
        limit = WIP_LIMITS.get(new_state)
        if limit and self._count(new_state) >= limit:
            raise BoardError(f"WIP limit {limit} reached in {new_state}")
        card.state = new_state

    def remaining(self):
        return sum(c.points for c in self.cards.values() if c.in_sprint and c.state != DONE)

    def end_day(self):
        self.burndown.append(self.remaining())

    def velocity(self):
        return sum(c.points for c in self.cards.values() if c.in_sprint and c.state == DONE)

    def column(self, state):
        return [c for c in self.cards.values() if c.state == state and (c.in_sprint or state == BACKLOG)]

    def render(self):
        lines = []
        for s in FLOW:
            ids = ", ".join(f"{c.cid}({c.points})" for c in self.column(s)) or "-"
            lines.append(f"{s:<16}| {ids}")
        return "\n".join(lines)
